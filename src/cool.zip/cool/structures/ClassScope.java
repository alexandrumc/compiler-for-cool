package cool.structures;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class ClassScope extends Symbol implements Scope{
	HashMap<String, IdSymbol> attributes;
	HashMap<String, MethodSymbol> methods;
	Scope parent = null;
	
	public ClassScope(String name) {
		super(name);
		this.attributes = new LinkedHashMap<>();
		this.methods = new LinkedHashMap<>();
	}
	
	public void setParent(Scope parent) {
		this.parent = parent;
	}

	public String getName() {
		return this.name;
	}
	
	public void print() {
		String res = "Metodele prezente: ";
		for (String s : methods.keySet()) {
			res += s;
			res += " ";
		}
		System.err.println(res);
	}
	
	@Override
	public boolean add(Symbol sym) {
		if (sym.getClass() == MethodSymbol.class) {
			if (methods.containsKey(sym.getName()))
				return false;
			methods.put(sym.getName(), (MethodSymbol) sym);
		} else if (sym.getClass() == IdSymbol.class) {
			if (attributes.containsKey(sym.getName()))
				return false;
			attributes.put(sym.getName(), (IdSymbol) sym);
		}
        return true;
	}

	@Override
	public Symbol lookup(String str) {
		return null;
	}
	
	@Override
	public Symbol lookupMethod(String str) {
		var sym = methods.get(str);
        
        if (sym != null) {
            return sym;
        }
        
        if (parent != null)
            return parent.lookupMethod(str);
        
        return null;
	}
	
	@Override
	public Symbol lookupAttribute(String str) {
		var sym = attributes.get(str);
		
        if (sym != null)
            return sym;
        
        if (parent != null)
            return parent.lookupAttribute(str);
        
        return null;
	}

	@Override
	public Scope getParent() {
		return parent;
	}

	@Override
	public boolean contains(String sym) {
		return false;
	}

	@Override
	public Symbol get(String sym) {
		return methods.get(sym);
	}

	@Override
	public Symbol inheritanceLookupMethod(String str) {
		if (parent != null)
            return parent.lookupMethod(str);
		return null;
	}


	@Override
	public Symbol inheritanceLookupAttribute(String str) {
		if (parent != null) {
            return parent.lookupAttribute(str);
		}
		return null;
	}
	
	
}
