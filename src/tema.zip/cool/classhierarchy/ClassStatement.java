package cool.classhierarchy;


public class ClassStatement extends Program {
	
}
