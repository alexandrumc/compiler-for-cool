package cool.structures;

public class TypeSymbol extends Symbol {
    public TypeSymbol(String name) {
        super(name);
    }
}
